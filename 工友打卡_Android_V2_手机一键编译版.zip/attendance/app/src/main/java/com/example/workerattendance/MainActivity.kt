package com.example.workerattendance

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity: Activity(){
 private lateinit var root: LinearLayout
 private val scanLauncher=registerForActivityResult(ScanContract()){ r ->
   if(r.contents!=null) showConfirm(r.contents) else toast("已取消扫码")
 }
 private fun tv(s:String,n:Float=16f)=TextView(this).apply{text=s;textSize=n;setTextColor(Color.rgb(30,40,55));setPadding(14,12,14,12)}
 private fun btn(s:String,a:()->Unit)=Button(this).apply{text=s;setOnClickListener{a()}}
 private fun base(t:String){root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,16,16,16);setBackgroundColor(Color.rgb(247,249,252))};root.addView(tv(t,22f));setContentView(root)}
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}
 private fun home(){base("工友打卡 · Android V2");root.addView(tv("真实二维码扫码测试",18f));root.addView(btn("👷 工头：打开摄像头扫码"){foreman()});root.addView(btn("🧑‍🔧 员工：显示个人二维码"){employee()});root.addView(btn("👑 老板：查看今日记录"){admin()})}
 private fun employee(){base("员工二维码");root.addView(tv("Ali bin Ahmad\n员工编号：EMP001",19f));root.addView(tv("\n\n██  ██ ███  █\n█ ███ █  ██ █\n██ █  ███ ███\n█  ███ █ ██ █\n██ █ ███  ██\n\n",26f).apply{gravity=Gravity.CENTER});root.addView(tv("正式版本这里会生成真实 QR Code"));root.addView(btn("返回"){home()})}
 private fun foreman(){base("工头扫码");root.addView(tv("工头：Ahmad\n工地：Putra Heights",18f));root.addView(btn("📷 开始真实扫码"){val o=ScanOptions();o.setPrompt("请扫描员工二维码");o.setBeepEnabled(true);o.setOrientationLocked(true);scanLauncher.launch(o)});root.addView(tv("\n扫码后系统会识别员工，并根据当天状态判断：\n未上班 → 上班\n已上班 → 午休出去\n午休中 → 午休回来\n已回来 → 下班"));root.addView(btn("返回"){home()})}
 private fun showConfirm(code:String){base("确认打卡");root.addView(tv("扫描内容：$code\n\n员工：Ali bin Ahmad\n工头：Ahmad\n工地：Putra Heights",18f));root.addView(btn("✅ 确认记录"){toast("打卡成功：系统已记录当前时间");foreman()});root.addView(btn("取消"){foreman()})}
 private fun admin(){base("老板 · 今日出勤");root.addView(tv("已上班：32\n午休中：2\n已下班：1\n未打卡：3",18f));root.addView(tv("\nAli · Ahmad · Putra Heights · 已下班\nKumar · Ahmad · Putra Heights · 午休中\nRavi · Tan · Subang · 已下班"));root.addView(btn("返回"){home()})}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
